from django.apps import AppConfig


class RestAppConfig(AppConfig):
    name = 'rest_app'
